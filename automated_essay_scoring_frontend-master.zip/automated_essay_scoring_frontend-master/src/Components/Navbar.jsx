
function Navbar() {
    return (
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <p 
                style={{
                    marginLeft:'42%', 
                    marginRight:'42%',
                    fontSize:'20px',
                    marginTop: '10px',
                }}
            >
                Automation Grading Score
            </p>
        </nav>
    )
}

export default Navbar;
